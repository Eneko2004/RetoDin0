package Controlador;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modelo.Cliente;
import modelo.Datos;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.Node;
public class ClienteController {

    @FXML private TextField txtDniCliente;
    @FXML private Button btnBuscar;

    // Metodo de buscar cliente 
@FXML
private void buscarCliente(ActionEvent event) {
    String dni = txtDniCliente.getText().trim();

    if (dni.isEmpty()) {
        mostrarAlerta(Alert.AlertType.WARNING, "Atención", "Debes introducir un DNI.");
        return;
    }

    Cliente clienteEncontrado = Datos.buscarClientePorDni(dni);

    // Si no se encuentra porque fue eliminado de Datos.listaClientes o nunca existió
    if (clienteEncontrado == null) {
        mostrarAlerta(Alert.AlertType.INFORMATION, "Cliente no disponible", "Cliente dado de baja, no se puede modificar.");
        return;
    }

    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/trabajador/Datoscliente.fxml"));
        Parent root = loader.load();

        DatosClienteController controller = loader.getController();
        if (controller != null) {
            controller.cargarClientePorDni(dni);
        }

        Stage stage = (Stage) btnBuscar.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();

    } catch (IOException e) {
        System.err.println("Error al cargar Datoscliente.fxml: " + e.getMessage());
        e.printStackTrace();
    }
}

//Metodo para mostrar las alertas
private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensaje) {
    Alert alert = new Alert(tipo);
    alert.setTitle(titulo);
    alert.setHeaderText(null);
    alert.setContentText(mensaje);
    alert.showAndWait();
}
}