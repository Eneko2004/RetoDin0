package Controlador;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modelo.Cliente;
import modelo.Datos;

public class DatosClienteController {

    @FXML private TextField txtNombre;
    @FXML private TextField txtEmail;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtFechaNacimiento;
    @FXML private TextField txtDni;
    @FXML private Button btnModificarDatos;
    @FXML private Button btnEliminarCliente;

    private Cliente clienteEncontrado;

    // Método para recibir el DNI desde ClienteController y buscar los datos
   public void cargarClientePorDni(String dni) {
    if (Datos.listaClientes != null) {
        for (Cliente c : Datos.listaClientes) {
            if (c.getApodo() != null && c.getApodo().trim().equalsIgnoreCase(dni.trim())) {
                clienteEncontrado = c;
                if (txtNombre != null) txtNombre.setText(c.getNombre());
                if (txtEmail != null) txtEmail.setText(c.getEmail());
                if (txtTelefono != null) txtTelefono.setText(String.valueOf(c.getTelefono()));
                break;
            }
        }
    }
}
   //Metodo para guardar datos del cliente 

@FXML
private void guardarDatosCliente(ActionEvent event) {
    if (clienteEncontrado != null) {
        clienteEncontrado.setNombre(txtNombre.getText());
        clienteEncontrado.setEmail(txtEmail.getText());
        try {
            clienteEncontrado.setTelefono(Integer.parseInt(txtTelefono.getText().trim()));
        } catch (NumberFormatException e) {
            mostrarAlerta(AlertType.ERROR, "Teléfono no válido", "El teléfono debe ser un número entero sin letras ni espacios.");
        }
        
        mostrarAlerta(AlertType.INFORMATION, "Cliente Modificado", "Los datos del cliente se han actualizado correctamente.");
        volverAVentanaTrabajador();
    } else {
        mostrarAlerta(AlertType.ERROR, "Error", "No se encontró el cliente para modificar.");
    }
}

//Metodo eliminar cliente con alertas 
    @FXML
    private void eliminarCliente(ActionEvent event) {
        if (clienteEncontrado != null && Datos.listaClientes != null) {
            Datos.listaClientes.remove(clienteEncontrado);
            
            mostrarAlerta(AlertType.INFORMATION, "Cliente Dado de Baja", "El cliente ha sido dado de baja correctamente.");
            volverAVentanaTrabajador();
        } else {
            mostrarAlerta(AlertType.ERROR, "Error", "No se pudo eliminar el cliente.");
        }
    }

    // Método para mostrar las ventanas emergentes (Popups)
    private void mostrarAlerta(AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    //Metodo para volver a la ventana del trabajador
    private void volverAVentanaTrabajador() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/trabajador/Trabajador.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage) btnModificarDatos.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.err.println("Error al regresar a Trabajador.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }
}