package Controlador;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modelo.Datos;
import modelo.Trabajador;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Alert;

public class VenatanaTrabajador {

    @FXML private TextField txtUsuario;    
    @FXML private TextField txtContrasena;   
    @FXML private TextField txtEmail;   
    @FXML private TextField txtSalario; 
    @FXML private Button btnModificarMisDatos;
    @FXML private Button btnModificarCliente;

    /**
     * Método de inicialización de JavaFX. 
     * Se ejecuta automáticamente tras cargar el archivo FXML y sirve para 
     * auto-rellenar los campos del formulario con la información del trabajador actual.
     */
    @FXML
    public void initialize() {
        // Comprueba que exista un trabajador logueado en la memoria de la aplicación
        if (Datos.trabajadorLogueado != null) {
            Trabajador t = Datos.trabajadorLogueado;
            
            if (txtUsuario != null) txtUsuario.setText(t.getNombre());
            if (txtContrasena != null) txtContrasena.setText(t.getContrasena());
            if (txtEmail != null) txtEmail.setText(t.getEmail());
            
            // Transforma el salario (double) a String para mostrarlo en el TextField
            if (txtSalario != null) txtSalario.setText(String.valueOf(t.getSalario())); 
        }
    }

    
     // Actualiza los datos del trabajador activo en la aplicacióncon los nuevos valores introducidos en el formulario.
     
    @FXML
    public void modificarMisDatos() {
        // Recoge los valores textuales de los campos del formulario
        String usuario = txtUsuario.getText().trim();
        String contrasena = txtContrasena.getText().trim();
        String email = txtEmail.getText().trim();
        String salarioTexto = txtSalario.getText().trim();

        //  Verifica si hay una sesión activa
        if (Datos.trabajadorLogueado != null) {
            try {
                // Conversión: Pasa el texto del salario a un número decimal (double)
                double salario = Double.parseDouble(salarioTexto);

                Trabajador t = Datos.trabajadorLogueado;
                t.setNombre(usuario);
                t.setContrasena(contrasena);
                t.setEmail(email);
                t.setSalario(salario);

                mostrarAlerta(AlertType.INFORMATION, "Datos Modificados", "Se han modificado tus datos correctamente.");

            } catch (NumberFormatException e) {
                mostrarAlerta(AlertType.ERROR, "Error de formato", "El salario debe ser un número válido");
            }
        } else {
            mostrarAlerta(AlertType.ERROR, "Error de Sesión", "No hay ningún trabajador logueado.");
        }
    }

    
     // Navega desde la pantalla actual hacia la vista de gestión de clientes (Cliente.fxml).
     
    @FXML
    private void modificarCliente(ActionEvent event) {
        try {
            // Carga el archivo FXML con la vista del cliente
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mycompany/trabajador/Cliente.fxml"));
            Parent root = loader.load();

            // Obtiene la ventana actual (Stage) e intercambia su escena por la nueva
            Stage stage = (Stage) btnModificarCliente.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            // Maneja posibles fallos al localizar o cargar la vista
            System.err.println("Error al cargar /vista/Cliente.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }

 //Metodo para mostrar las alertas 
    private void mostrarAlerta(AlertType tipo, String titulo, String mensaje) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
    }
}