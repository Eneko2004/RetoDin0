package modelo;

public class Cliente extends Personal {
    private int telefono;
    private String apodo;
    private String direccion;

    public Cliente(int id, String nombre, String email, String contrasena, 
                   int telefono, String apodo, String direccion) {
        super(id, nombre, email, contrasena);
        this.telefono = telefono;
        this.apodo = apodo;
        this.direccion = direccion;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getApodo() {
        return apodo;
    }

    public void setApodo(String apodo) {
        this.apodo = apodo;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Cliente{" + "telefono=" + telefono + ", apodo=" + apodo + ", direccion=" + direccion + '}';
    }

 
}