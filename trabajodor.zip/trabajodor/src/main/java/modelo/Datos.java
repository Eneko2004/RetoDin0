package modelo;

import java.util.ArrayList;
import java.util.List;

public class Datos {

    public static Trabajador trabajadorLogueado;
    public static List<Cliente> listaClientes = new ArrayList<>();
    public static List<Trabajador> listaTrabajadores = new ArrayList<>();

    // Se ejecuta de forma automática al iniciar la app
    static {
        crearPersonales();
    }

    public static void crearPersonales() {
        Trabajador t1 = new Trabajador(1, "Carlos", "carlos@gmail.com", "1234", 1500.0);
        listaTrabajadores.add(t1);
        trabajadorLogueado = t1;

        Cliente c1 = new Cliente(101, "Juan Pérez", "juan@gmail.com", "1234", 654321987, "12345678X", "Calle Mayor 1");
        listaClientes.add(c1);
    }

    public static void registrarCliente(Cliente nuevoCliente) {
        listaClientes.add(nuevoCliente);
        System.out.println("Cliente registrado con éxito.");
    }

    public static boolean iniciarSesionTrabajador(String email, String contrasena) {
        for (Trabajador t : listaTrabajadores) {
            if (t.getEmail().equalsIgnoreCase(email) && t.getContrasena().equals(contrasena)) {
                trabajadorLogueado = t;
                return true;
            }
        }
        return false;
    }

    // Comprueba tanto el campo DNI como el apodo para evitar fallos de coincidencia
    public static Cliente buscarClientePorDni(String dni) {
        for (Cliente c : listaClientes) {
            if (c.getApodo() != null && c.getApodo().trim().equalsIgnoreCase(dni.trim())) {
                return c;
            }
        }
        return null;
    }
}