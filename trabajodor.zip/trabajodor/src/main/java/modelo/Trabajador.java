package modelo;

import java.time.LocalDate;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Eneko.Plaza
 */
public class Trabajador extends Personal{
    private double salario;

    public Trabajador(int id, String nombre, String email, String contrasena,double salario) {
        super(id, nombre, email, contrasena);
        this.salario = salario;
    }



    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        return "Trabajador{" + "salario=" + salario + '}';
    }

    
    
}