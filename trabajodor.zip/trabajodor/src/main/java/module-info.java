module com.mycompany.trabajodr {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.trabajador to javafx.fxml;
    exports com.mycompany.trabajador;
    opens Controlador to javafx.fxml;
exports Controlador;
}
